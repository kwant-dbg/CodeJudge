#!/bin/sh
cd /home/site/wwwroot
chmod +x codejudge-monolith
./codejudge-monolith